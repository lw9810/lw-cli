import { defineComponent } from "vue";

export default defineComponent({
    name:'tree',
    setup() {
        
    },
    render(){
        return <>tree</>
    }
})