import { defineComponent, reactive, shallowRef } from "vue";
import lTable from "@/components/Table/index";

export default defineComponent({
    name: 'Table',
    setup() {
        return {}
    },
    render() {
        return <>
            <lTable ></lTable>
        </>
    }
})