import { defineComponent, reactive, shallowRef, defineProps, defineEmits } from "vue";

export default defineComponent({
    name: 'lTable',
    setup() {
        const props = defineProps({
            table: Object,
            pagination: Object
        })
        const emit = defineEmits(['pageChange', 'pageSizeChange'])
        const oninput = (val, event, row) => {
            console.log(val, event, row)
        }

        const columns = shallowRef([{
            title: 'Name',
            dataIndex: 'name',
            slotName: 'name',
            slot: (record, rowIndex) => <a-input onInput={(value, event) => { oninput(value, event, record) }} v-model={record.name} />
        }, {
            title: 'Salary',
            dataIndex: 'salary',
        }, {
            title: 'Address',
            dataIndex: 'address',
        }])
        const data = reactive([{
            key: '1',
            name: 'Jane Doe',
            salary: 23000,
            address: '32 Park Road, London',
            province: 'Beijing',
            city: 'Haidian',
            email: 'jane.doe@example.com'
        }, {
            key: '2',
            name: 'Alisa Ross',
            salary: 25000,
            address: '35 Park Road, London',
            email: 'alisa.ross@example.com'
        }])
        const soltData = shallowRef({})

        columns.value.forEach(item => {
            if (item.slotName) {
                soltData.value[item.slotName] = item.slot
            }
        })
        const table = reactive({ columns, data, pagination: false })
        const pagination = reactive({
            total: 50,
            current: 1,
            pageSize: 10
        })
        const pageChange = (current) => {
            emit('pageChange', current)
            pagination.current = current
        }
        const pageSizeChange = (pageSize) => {
            emit('pageSizeChange', pageSize)
            pagination.pageSize = pageSize
        }
        return { table, soltData, pagination, pageChange, pageSizeChange }
    },
    render() {
        const { table, soltData, pagination, pageChange, pageSizeChange } = this
        return <>
            <a-space direction="vertical" fill>
                <a-table {...table}>{soltData}</a-table>
                <a-pagination {...pagination} onChange={pageChange} onPageSizeChange={pageSizeChange} show-total show-jumper show-page-size />
            </a-space>
        </>
    }
})